package com.admiral.web;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;


@RunWith(Cucumber.class)

@CucumberOptions( format={"json:target/cucumber.json", "html:target/cucumber"},
features="src/test/resources", tags= " @AdmiralWebLaunch", 
plugin={"html:out"})
//clean verify -Dcucumber.options="--tags @createContactDetail1"
public class RunnerTest {

}

